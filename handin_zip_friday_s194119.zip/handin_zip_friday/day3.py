#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun  6 13:33:44 2023

@author: max
"""

import numpy as np
import matplotlib.pyplot as plt 
import scipy.stats as st

class customerSimulation:
    def __init__(self,n_customers,mean_arrival_time,n_cashiers,mean_service_time,n_experiments,arrivalmode=None,servicemode=None):
        self.n_c = n_customers
        self.cashier_capacity = n_cashiers
        self.cashiers_occupied = 0
        self.clock = 0 #arbitrary time-unit
        self.n_e = n_experiments
        self.n_rejected = 0
        self.CASHIERS_FREE = True
        self.cashier_time = []
        self.total_customers = n_experiments*n_customers
        self.arrivalTimes = self.initialize_arrivals(mean_arrival_time,arrivalmode)
        self.departureTimes = self.initialize_departures(mean_service_time,servicemode)
        self.rejected_results = [] #holds number rejected for experiments 
        self.clockResults = []
        self.meanArrivalTime = mean_arrival_time
        self.meanServiceTime = mean_service_time
        
        
    def initialize_arrivals(self,mat,arrivalmode=None):
        if(arrivalmode==None):
            X = np.random.poisson(lam=mat,size=self.n_c).tolist()
            return X
        elif(arrivalmode=="erlang"):
            mean = 1
            shape_k = 1
            X = np.random.gamma(shape=shape_k,scale=mean).tolist()
            return X
        elif(arrivalmode=="hyperexponential"):
            p = 0.8
            lambda1 = 0.833333
            lambda2 = 5.0
            X = np.zeros(self.n_c)
            P = np.random.uniform(0,1,size=self.n_c)
            X[P <= p] = -np.log(1-np.random.uniform(0,1,size=(P <= p).sum()))/lambda1;
            X[P > p]  = -np.log(1-np.random.uniform(0,1,size=(P >  p).sum()))/lambda2;
            return X.tolist()
        
    
    def initialize_departures(self,mst,servicemode=None):
        if(servicemode==None):
            return np.random.exponential(scale=mst,size=self.n_c).tolist()
        elif(servicemode=="constant"):
            return [mst for x in range(self.n_c)]
        elif(servicemode=="pareto1"):
            k = 1.05
            return st.pareto.rvs(k,scale=mst*(k-1)/k,size=self.n_c).tolist()
        elif(servicemode=="pareto2"):
            k = 2.05
            return st.pareto.rvs(k,scale=mst*(k-1)/k,size=self.n_c).tolist()
        elif(servicemode=="gaussian"):
            return (mst*np.random.uniform(size=self.n_c)).tolist()  
        
    
    def reinitialize(self):
        self.clock = 0
        self.n_rejected = 0
        self.cashier_time = []
        self.arrivalTimes = self.initialize_arrivals(self.meanArrivalTime)
        self.departureTimes = self.initialize_departures(self.meanServiceTime)
        return None
    
    def get_next_event(self):
        ###Extracts arrival time and departure-time and removes entries from event-lists
        at = self.arrivalTimes[0]
        dt = self.departureTimes[0]
        self.arrivalTimes.pop(0)
        self.departureTimes.pop(0)
        return at,dt
    
    def assign_to_cashier(self,arrivalt,departuret):
        self.cashier_time = [x-arrivalt for x in self.cashier_time] #update passed time
        self.cashier_time = [x for x in self.cashier_time if x>0] #remove from cashier if service has been finished
        if(len(self.cashier_time)==self.cashier_capacity): #all cashiers are busy - reject customer 
            self.n_rejected += 1 
        else:
            self.cashier_time.append(departuret)
        return None
            
    def runSim(self):
        while(len(self.arrivalTimes)>0):
            at,dt = self.get_next_event()
            old_clock = self.clock
            self.clock += at
            self.assign_to_cashier(at,dt)
            #update cashier time 
        self.rejected_results.append(self.n_rejected)
        self.clockResults.append(self.clock)
        return None
    
    def runSimMultiple(self,n_experiments):
        self.runSim() #already initialized
        for i in range(n_experiments-1):
            self.reinitialize()
            self.runSim()
        return None
    
    def printResults(self):
        print(f"Number of rejected customers: {self.rejected_results}")
        print(f"Clock time for finished service: {self.clockResults}")
        return None
    
    def getRejectedResults(self):
        return self.rejected_results
    
    def getClockResults(self):
        return self.clockResults
            
    def getTheoreticalRejectedResult(self):
        A = self.meanArrivalTime*self.meanServiceTime
        numerator = (A**self.cashier_capacity)/np.math.factorial(self.cashier_capacity)
        denominator = sum([(A**i)/np.math.factorial(i) for i in range(self.cashier_capacity+1)])
        return numerator/denominator
        
    def extractStatistic(self,descriptor,alpha):
        if(descriptor=="clock"):
            theta = self.clockResults
        elif(descriptor=="rejections"):
            theta = self.rejected_results
        
        #estimate mean on per-experiment basis 
        theta_mean = [x/self.n_c for x in theta] #get per-experiment fraction
        print(theta_mean)
        #estimate fraction across number of experiments 
        theta_exp_mean = sum(theta_mean)/self.n_e
        print(theta_exp_mean)
        squared_diff = [x**2 - theta_exp_mean**2 for x in theta_mean]
        print(squared_diff)
        var = 1/(self.n_e-1)*sum(squared_diff)
        print(var)
        ci_val = (np.sqrt(var)/np.sqrt(self.n_e))*st.t.interval(confidence=0.95,df=self.n_e-1)[1] #positive entry
        CIL = [theta_exp_mean - ci_val, theta_exp_mean + ci_val]
        return theta_exp_mean,var,CIL
        
                

#general params
n_c = 10000
n_e = 10
m_serv = 10 #number of service units 

#setup exc 4: 1
mean_arrival_time = 1
mean_service_time = 8
SIM = customerSimulation(n_c,mean_arrival_time,m_serv,mean_service_time,n_e)
SIM.runSimMultiple(n_experiments=n_e)
n_rejected = SIM.getRejectedResults()
theoreticalB = SIM.getTheoreticalRejectedResult()

print(theoreticalB)
thetaMeasured, variance_measured, confint = SIM.extractStatistic("rejections",0.95)
#get the absolute difference
print(f"Absolute difference theoretical and simulated: {abs(thetaMeasured-theoreticalB)}")

#quite small error

        
    
