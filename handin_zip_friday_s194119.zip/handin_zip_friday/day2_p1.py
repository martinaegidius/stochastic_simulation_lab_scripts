#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun  2 10:36:31 2023

@author: max
"""

import numpy as np 
import matplotlib.pyplot as plt 
n = 10000
p = 0.3

Geo_sample = np.random.geometric(p, size=n)
Unif_sample = np.random.uniform(size=n)

def uniform_to_geometric(x,p):
    return np.floor(np.log(x)/np.log(1-p))+1

Geo_trf = uniform_to_geometric(Unif_sample,p)

# plot them bois 
fig, ax = plt.subplots(1,2)
ax[0].hist(Geo_sample)
ax[1].hist(Geo_trf)

###simulate the 6 point distribution with 7/48,5/48,1/8,1/16,1/4,5/16
###USING CRUDE METHOD 

def uniform_to_sixpoint_crude(X,p):
    F = np.cumsum(p)#CDF-values 
    SIM_CRUDE = []
    for i in range(len(Unif_sample)):
        U = Unif_sample[i]
        idx = 0.0
        for j in range(len(F)):
            if(j==0):
                if(U<=F[j+1]):
                    idx = 0
            elif(U>F[j-1] and U<=F[j]):
                idx = j
        SIM_CRUDE.append(X[idx])
    return SIM_CRUDE

X = [1,2,3,4,5,6]
pp = np.array([7/48,5/48,1/8,1/16,1/4,5/16]) #save probabilities 
six_point_crude = uniform_to_sixpoint_crude(X,pp)  
plt.figure()
plt.hist(six_point_crude,density=True,bins=6)


####SIMPLE REJECTION METHOD 
def simple_rejection_method(k,p,n):
    c = max(p/(1/k))
    SIM = []
    while(len(SIM)<n):
        U1 = int(np.floor(k*np.random.uniform(0,1)))+1
        U2 = np.random.uniform(0,1)
        if(U2<=p[U1-1]/c):
            SIM.append(U1)
    return SIM 

SIM_REJECT_SIMPLE = simple_rejection_method(6,pp,10000)
plt.figure()
plt.hist(SIM_REJECT_SIMPLE,density=True,bins=6)

#####ALIAS REJECTION METHOD 
#setup tables
def setup_alias_tables(k,p):
    L = np.array([x for x in range(1,k+1)])
    F = k*np.array(p) #note: do not have to sum to one
    G = F>1 #overfull group
    G = np.where(G)[0] #cast boolean mask to index array
    S = F<1 #underfull group
    S = np.where(S)[0]
    #eps = np.finfo(float).eps
    eps = 1e-08
    F = F.tolist()
    L = L.tolist()
    G = G.tolist()
    S = S.tolist()
    #Generate table
    while(len(S)!=0):
        i = G[0]
        j = S[0]
        L[j] = i
        F[i] = F[i]-(1-F[j])
        if(F[i]<1-eps): #close enough to being balanced "equal" - remove from overfull group and add to underfull+equal group
            G.pop(0)
            S.append(i)
        S.pop(0)
    return F,L

def setup_alias_tables2(k,p):
    #https://www.cs.toronto.edu/~gdahl/papers/aliasMethod.pdf
    S = []
    L = []
    q = p*k #prevent overwriting
    for i in range(k):
        qi = q[i]
        if(qi<1):
            S.append(i)
        else:
            L.append(i)
    J = [0 for x in range(k)]
    counter = 0
    while(len(S)!=0):
        #print(counter)
        #print(L)
        #print(S)
        l = L[-1]
        s = S[-1]
        J[s] = l
        q[l] = q[l]-(1-q[s])
        S.pop(-1)
        if(q[l]<1):
            L.pop(-1)
            S.append(l)
        counter += 1
    return J,q #J is your L, q is your F

def alias_rejection_method(p,n_points):
    L,F = setup_alias_tables2(k=len(p),p=p)
    #print(F)
    SIM = []
    k = len(F)
    while(len(SIM)<n_points):
        U1 = int(np.floor(k*np.random.uniform(0,1)))+1 #no zeros - add 1 
        print("Generated point ",U1)
        U2 = np.random.uniform(0,1) #lottery draw
        print(f"Lottery draw result {U2}/{F[U1-1]}")
        if(U2<F[U1-1]):#zero-based indexing
            SIM.append(U1)
            print("ACCEPTED")
        else:
            SIM.append(L[U1-1])
            print(f"Appended {L[U1-1]}")
    return SIM


J,q = setup_alias_tables2(k=6,p=pp)
SIMALIAS = alias_rejection_method(pp,100)
plt.figure()
plt.hist(SIMALIAS,density=True,bins=6) #for some reason the table-generation scheme is wrong
    
    
    