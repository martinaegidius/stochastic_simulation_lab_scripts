#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun  2 14:44:15 2023

@author: max
"""

import numpy as np 
import matplotlib.pyplot as plt 
import scipy 

#generate points 
n = 10000
U = np.random.uniform(size=n)


####                                GENERATE EXPONENTIAL DIST               
lambd = 0.3 
sim_exp = -np.log(U)/lambd
exp_ref = np.random.exponential(scale=1/lambd,size=n)
fig, ax = plt.subplots(1,2)
#make analytical pdf 
x = np.linspace(0,30,1000)
ax[0].hist(exp_ref,density=True)
ax[0].plot(x,scipy.stats.expon.pdf(x,scale=1/lambd))
ax[1].hist(sim_exp,density=True)
ax[1].plot(x,scipy.stats.expon.pdf(x,scale=1/lambd))
plt.show()
#test distribution 
ts,p_val = scipy.stats.kstest(sim_exp,"expon",args=(0,1/lambd))
print(p_val)
if(p_val>0.05):
    print("KS says exp-dist")


####                                GENERATE GAUSSIAN BOX-MULLER 
#reference distribution 
norm_ref = np.random.normal(loc=0,scale=1,size=n)#standard-normal
U1 = U[:n//2]
U2 = U[n//2:]
NORM_SIM = np.empty((n,1))
coord_cartesian = lambda entry : np.array([[np.cos(2*np.pi*entry)],[np.sin(2*np.pi*entry)]])
for i in range(n//2):
    tmp = np.sqrt(-2*np.log(U1[i]))
    print(tmp)
    NORM_SIM[i*2:i*2+2] = tmp*coord_cartesian(U2[i])
    print(coord_cartesian(U2[i]))
    
fig, ax = plt.subplots(1,2)
x = np.linspace(min(NORM_SIM),max(NORM_SIM),1000)
ax[0].hist(norm_ref,density=True)
ax[0].plot(x,scipy.stats.norm.pdf(x,loc=0,scale=1))

ax[1].hist(NORM_SIM,density=True)
ax[1].plot(x,scipy.stats.norm.pdf(x,loc=0,scale=1))
plt.show()

#test 
NORM_SIM = np.squeeze(NORM_SIM,axis=-1)
ts,p_val = scipy.stats.kstest(NORM_SIM,"norm",args=(0,1)) #FAILS KS-HYPOTHESIS TEST
#test if from same distribution 
tseq,pval_eq = scipy.stats.ks_2samp(NORM_SIM,norm_ref) 



#####                                 PARETO DISTRIBUTION
beta = 1  #scale
k_li = [2.05,2.5,3,4] #shape

fig, ax = plt.subplots(len(k_li),2)
for i, k in enumerate(k_li):
    PARETO_SIM = beta*np.power(U,-1/k) #SHOULD BE LARGER THAN 1 
    pareto_ref = (np.random.pareto(k,size=n)+1)*1
    x = np.linspace(min(PARETO_SIM),max(PARETO_SIM),1000)
    ax[i,0].hist(pareto_ref,density=True,bins=10)
    ax[i,0].plot(x,scipy.stats.pareto.pdf(x,b=k,loc=1,scale=beta))
    ax[i,1].hist(PARETO_SIM,density=True,bins=10)
    ax[i,1].plot(x,scipy.stats.pareto.pdf(x,b=k,loc=1,scale=beta))
    #test 
    ts,p_val = scipy.stats.kstest(PARETO_SIM,"pareto",args=(k,1,beta)) #FAILS KS-HYPOTHESIS TEST
    print(f"KS-test k={k}, p-val: {p_val}")
plt.show()

#this one is hard as fuck 
