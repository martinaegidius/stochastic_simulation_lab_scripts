#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun  1 13:13:12 2023

@author: max
"""

import numpy as np 
import matplotlib.pyplot as plt
import scipy


def LCGRANDGEN(a=1103515245,c=12345,M=2**31,num_points=10000):
    #LCG = [(a*x+c)%M for x[i-1] in ]
    rand_points = np.empty((num_points,1))
    rand_points[0] = 3
    for i in range(1,num_points):
        rand_points[i] = ((a*rand_points[i-1]+c)%M)
        
    rand_points = rand_points/M
    return rand_points 

X = LCGRANDGEN()  
plt.figure(13)
plt.hist(X,bins=10,color="red")

plt.figure(14)
idx_arr = np.arange(0,len(X))
plt.scatter(idx_arr,X,s=1) #definitely not random 

''
#get chisq-test
def chisq_uniform(x,nbins=10):    
    counts, _ = np.histogram(x,bins=nbins)
    n_expected = len(x)/len(counts)
    T = [(c - n_expected)**2/n_expected for c in counts]
    S = sum(T)
    df = nbins-1
    p = scipy.stats.chi2.pdf(S,df)
    if(p>0.05):
        print("SEEMS UNIFORM :)")
    else:
        print("REJECTED")
    return T,p


T, p = chisq_uniform(X)
    
###kolmogorov 
x_sorted = np.sort(X,axis=0)
F_emp = np.zeros((len(x_sorted),1))
F_teo = np.linspace(0,1,len(x_sorted))
F_teo = np.expand_dims(F_teo,-1)
for i, entry in enumerate(x_sorted):
    len_total = len(x_sorted)
    F_emp[i] = (i)/(len_total)
    
def ecdf(x):
    xs = np.sort(x)
    ys = np.arange(1, len(xs)+1)/float(len(xs))
    return xs, ys

KSECDFX,KSECDFY = ecdf(X)
KSECDFY = np.expand_dims(KSECDFY,-1)
    
plt.figure(0)
plt.plot(KSECDFX,KSECDFY)
plt.plot(x_sorted,x_sorted)
#plt.legend("Empirical","Theoretical")
    
#get supremum of distance 
diff = np.abs(KSECDFY-x_sorted)
mD = max(diff)
idx_md = np.argmax(diff)
plt.figure(19)
plt.plot(x_sorted,F_emp)
plt.plot(x_sorted,x_sorted)
plt.scatter(idx_md,F_teo[idx_md],c="red")

ts = (np.sqrt(len(x_sorted))+0.12+0.11/np.sqrt(len(x_sorted)))*mD #is below  all significance levels. Should be larger than, I think? 

def wald_wolfowitz(x,VERBOSE=True):
    med = np.median(x)
    entry = x[0]
    current_idx = 0
    runs_below = 0
    runs_above = 0
    while(current_idx<len(x)-1):
        print(current_idx)
        if(entry>=med):
            num_above = 1
            len_a = 0
            runs_above += 1
            while(entry>=med and current_idx<len(x)-1):
                len_a += 1 
                current_idx += 1 #check next point
                print("above run at ",current_idx,entry)
                entry = x[current_idx] #check next point
        else:
            num_below = 1
            runs_below += 1 
            while(entry<med and current_idx<len(x)-1):
                current_idx += 1 #check next point
                print("below run at ",current_idx,entry)
                entry = x[current_idx] #check next point
                
    if(x[-1]>=med and x[-2]<med):
        runs_above += 1 
    elif(x[-1]<med and x[-2]>=med):
        runs_below += 1
    
    Z = runs_above + runs_below
    #make test
    n1 = len([i for i in x if i >= med]) #n_above
    n2 = len([i for i in x if i < med]) #n_below 
    n_prod = n1*n2
    mean_asymp_dist = 1+2*n_prod/(n1+n2)
    var_asymp_dist = 2*(n_prod*(2*n_prod-n1-n2))/((n1+n2)**2*(n1+n2-1))    
    p_val = 2*(1-scipy.stats.norm.cdf(Z,loc=mean_asymp_dist,scale=var_asymp_dist))
    
    return runs_above + runs_below, runs_above, runs_below, p_val

#debugging case: 
test_list = [1, 2, -1, 1, 1, 0]#median 1.0
print(np.median(test_list))
print(wald_wolfowitz(test_list))
#number above-runs: 3
#number below runs: 3



        
